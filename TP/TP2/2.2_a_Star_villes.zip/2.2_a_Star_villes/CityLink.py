import os

class City :
    def __init__(self,name,x,y):
        self.name = name
        self.X = int(x)
        self.Y = int(y)
        self.links = []
        self.parent=None
        
    def __str__(self):
        return str(self.name)

    def getNeighbors(self,dicCity):
        neighbors=[]
        #print ("voisin de "+self.name)
        for l in self.links:
            #print("- "+str(l.destination)+", "+str(l.weight))
            neighbors.append(dicCity[str(l.destination)])
        return neighbors

    def getWeightOf(self,destination):
        for l in self.links:
            if str(l.destination)==str(destination.name):
                return int(str(l.weight))

    def getLinksStr(self):
        out=""
        for e in self.links:
            dest=str(e.destination)
            wgt=str(e.weight)
            out+=(" -est liée à: "+dest+",pour: "+wgt)
        return out

    def createLinks(self,link):
        self.links.append(link)
    def getPos(self):
        return (self.x,self.y)
        
####################################
class Links:
    def __init__(self,destination,weight):
        self.destination=destination
        self.weight=weight
####################################

#PARSING
def readCityFile(dicCity):
    file=open("./data/positions.txt","r")
    for linePos in file:
        name,x,y=linePos.split()
        dicCity[name]=City(name,x,y)

def readLinksFile(dicCity):
    file=open("./data/connections.txt","r")
    for lineCon in file:
        src,dst,weight=lineCon.split()
        try:
            dicCity[src].createLinks(Links(dicCity[dst],weight))
            dicCity[dst].createLinks(Links(dicCity[src],weight))
        except:
            print("error in file")

def readAll():
    dicCity={}
    readCityFile(dicCity)
    readLinksFile(dicCity)
    return dicCity